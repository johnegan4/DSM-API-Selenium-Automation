package org.junit;

public class Assert {

}
